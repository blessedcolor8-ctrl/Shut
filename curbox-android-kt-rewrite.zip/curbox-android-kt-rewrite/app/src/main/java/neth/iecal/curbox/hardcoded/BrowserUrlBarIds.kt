package neth.iecal.curbox.hardcoded

import neth.iecal.curbox.data.models.BrowserUrlBarInfo


val URL_BAR_ID_LIST = mapOf(
    "com.android.chrome" to BrowserUrlBarInfo(
        displayUrlBarId = "com.android.chrome:id/url_bar",
    ),
    "org.cromite.cromite" to BrowserUrlBarInfo(
        displayUrlBarId = "org.cromite.cromite:id/url_bar",
    ),
    "app.vanadium.browser" to BrowserUrlBarInfo(
        displayUrlBarId = "app.vanadium.browser:id/url_bar",
    ),
    "com.brave.browser" to BrowserUrlBarInfo(
        displayUrlBarId = "com.brave.browser:id/url_bar",
    ),
    "com.vivaldi.browser" to BrowserUrlBarInfo(
        displayUrlBarId = "com.vivaldi.browser:id/url_bar",
    ),
    "org.calyxos.chromium" to BrowserUrlBarInfo(
        displayUrlBarId = "org.calyxos.chromium:id/url_bar",
    ),

    
    "org.mozilla.focus" to BrowserUrlBarInfo(
        displayUrlBarId = "org.mozilla.focus:id/mozac_browser_toolbar_url_view",
    ),

    "org.mozilla.firefox" to BrowserUrlBarInfo(
        displayUrlBarId = "ADDRESSBAR_URL_BOX",
    ),

    "org.mozilla.fennec_fdroid" to BrowserUrlBarInfo(
        displayUrlBarId = "ADDRESSBAR_URL_BOX",
    ),
    "org.ironfoxoss.ironfox" to BrowserUrlBarInfo(
        displayUrlBarId = "ADDRESSBAR_URL_BOX",
    ),
    "io.github.forkmaintainers.iceraven" to BrowserUrlBarInfo(
        displayUrlBarId = "ADDRESSBAR_URL_BOX",
    ),
    

    "com.opera.browser" to BrowserUrlBarInfo(
        displayUrlBarId = "com.opera.browser:id/url_field",
    ),
    "io.github.jqssun.helium" to BrowserUrlBarInfo(
        displayUrlBarId = "io.github.jqssun.helium:id/url_bar",
    ),
)
